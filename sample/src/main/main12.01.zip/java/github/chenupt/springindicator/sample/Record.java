package github.chenupt.springindicator.sample;


public class Record {
    public int year;
    public int month;
    public int date;
    public int count;

    Record(int year, int month, int date, int count){
        this.year=year;
        this.month=month;
        this.date=date;
        this.count=count;
    }
}
