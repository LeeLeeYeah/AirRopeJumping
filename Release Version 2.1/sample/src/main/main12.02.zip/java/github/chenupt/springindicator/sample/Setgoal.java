package github.chenupt.springindicator.sample;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.IOException;

public class Setgoal extends ActionBarActivity {
    SeekBar seekBar;
    Toolbar toolbar;
    TextView curgoal;
    TextView setgoal;

    public void writeFile(String record) throws IOException {
        SharedPreferences.Editor editor = getSharedPreferences("count", Context.MODE_PRIVATE).edit();
        //步骤2-2：将获取过来的值放入文件
        editor.putString("record", record);
        editor.commit();
    }
    public void saveData(){
        //@CLF
        String towrite=""+MainActivity.goal+"\n";

        for(int i=0;i<MainActivity.records.length;i++)
        {
            towrite+=""+MainActivity.records[i].year+" "+MainActivity.records[i].month+" "+MainActivity.records[i].date+" "+MainActivity.records[i].count+"\n";
        }
        try {
            writeFile(towrite);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setgoal);

    }

    @Override
    protected void onResume() {
        super.onResume();
        seekBar = (SeekBar) findViewById(R.id.myseekbar);

        setgoal = (TextView) findViewById(R.id.setgoal);
        curgoal=(TextView)findViewById(R.id.cur_goal);
        toolbar = (Toolbar) findViewById(R.id.setgoalbar);
        toolbar.setTitle("设定目标");
        curgoal.setText("" + MainActivity.goal);
        seekBar.setProgress(MainActivity.goal/2);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int goal=seekBar.getProgress()*2;
                curgoal.setText("" + goal);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        setgoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int goal=seekBar.getProgress()*2;
                MainActivity.goal=goal;

                Intent in=new Intent(Setgoal.this,MainActivity.class);
                startActivity(in);
                finish();
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveData();
    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.menu_setgoal, menu);
//        return true;
//    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        if (id == android.R.id.home) {
            finish();
            return true;
        }


        return super.onOptionsItemSelected(item);
    }
}
